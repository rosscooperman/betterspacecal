#!/bin/sh

COUNT=14

while [ ${COUNT} -le 2461 ] 
do
  NUM=`echo ${COUNT} | awk '{printf("%04d",$1)}'`
  echo "${NUM}"

  [ ! -s "${NUM}.html" ] && curl --silent http://xmm2.esac.esa.int/user/mplan/summaries/${NUM}_nice.html > ${NUM}.html
  COUNT=`expr ${COUNT} + 1`
done

exit 0
